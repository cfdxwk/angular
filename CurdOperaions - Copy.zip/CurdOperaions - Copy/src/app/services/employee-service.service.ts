import { Injectable } from '@angular/core';
import { Employee } from '../employee';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
//import {  } from "../../assets/Em";
@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  url = '../../assets/Employee.json';
  constructor(private http: HttpClient) {
    this.fetchData();
  }
  employees: Employee[] = [];
  ind:number;
  getEmployees():Employee[]{
    return this.employees;
  }

  fetchData(){
    this.getData().subscribe(data=>{
      this.employees = data;
    }, err=>{
      console.log(err);
    });
  }

  getData():Observable<Employee[]>{
    return this.http.get<Employee[]>(this.url);
  }

  addEmployee(employee:Employee){
    this.employees.push(employee);
  }

  deleteEmployee(index){
    this.employees.splice(index,1);
  }
   
  findEmployeeById(){
    return this.employees[this.ind];
  }

  updateEmployee(index){
    this.ind=index;

  }

  saveChanges(employee){
    this.employees[this.ind]=employee;
  }

}
