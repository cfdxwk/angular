import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../services/employee-service.service';
import { Employee } from '../employee';
import { Router } from "@angular/router";

@Component({
  selector: 'app-show-employees',
  templateUrl: './show-employees.component.html',
  styleUrls: ['./show-employees.component.css']
})
export class ShowEmployeesComponent implements OnInit {

  constructor(private employeeService:EmployeeServiceService, private router:Router) { }

  employees:Employee[];

  ngOnInit() {
    this.employees = this.employeeService.getEmployees();
    console.log(this.employees);
  }

  deleteEmployee(index){
    this.employeeService.deleteEmployee(index);
  }

  updateEmployee(index){
    this.employeeService.updateEmployee(index);
    this.router.navigate(['update']);
  }

}
