import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../services/employee-service.service';
import {Employee} from '../employee';
import { Router  } from "@angular/router";

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employee:Employee={id:'',name:'',email:''};
  constructor(private employeeService: EmployeeServiceService, private router:Router) { }

  ngOnInit() {


  }
  addEmployee(){
    this.employeeService.addEmployee(this.employee);
    alert("Employee added successfully");
    this.router.navigate(['list']);
  }
}
