import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeServiceService } from '../services/employee-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  constructor(private employeeService:EmployeeServiceService, private router: Router) { }
  employee:Employee;

  ngOnInit() {
    this.employee=this.employeeService.findEmployeeById();
  }

  saveChanges(){
    this.employeeService.saveChanges(this.employee);
    this.router.navigate(['list']);
  }

}
